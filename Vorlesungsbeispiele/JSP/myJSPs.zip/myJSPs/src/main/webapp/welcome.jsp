<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="ISO-8859-1">
      <title>Willkommen</title>
   </head>
   <body>
      <jsp:useBean id="mybean" class="de.htwg.mybean.MyBean"></jsp:useBean>  
      <jsp:setProperty property="*" name="mybean"/> 
  
      Das sind die eingegebenen Daten:<br>  
      Name: <jsp:getProperty property="name" name="mybean"/><br>  
      Passwort: <jsp:getProperty property="password" name="mybean"/><br>  
      Email: <jsp:getProperty property="email" name="mybean" /><br>  
   </body>
</html>