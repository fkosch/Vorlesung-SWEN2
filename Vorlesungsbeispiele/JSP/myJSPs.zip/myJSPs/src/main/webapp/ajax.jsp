<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("button").click(function(){
        $.get("http://localhost:8080/easynotes/api/notes", function(notes){
            createTable(notes);
        });
    });
});

function createTable(notes) {
	var txt="<table border=\"1\"><tr><th>Bemerkung</th><th>Inhalt</th><th>created</th></tr>"
	$.each( notes, function( key, note ) {
	    txt+="<tr><td>"+note.title+"</td><td>"+note.content+"</td><td>"+note.created+"</td></tr>";
	});
	$("#paragraph").html(txt + "</table>");
}
</script>
<title>AJAX-Example</title>
</head>
<body>

<button>Send an HTTP GET request to a page and get the result back</button>
<p></p>

<p id="paragraph"></p>

</body>
</html>