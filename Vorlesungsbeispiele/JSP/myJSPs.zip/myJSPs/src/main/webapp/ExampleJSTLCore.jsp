<%@page pageEncoding="UTF-8" contentType="text/html; charset=UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
	<title>Example JSTL-Core</title>
</head>
<body>
	<jsp:useBean id="data" class="de.htwg.mybean.Data"></jsp:useBean>
	<table class="table table-striped">
		<tr><th>Nummer</th><th>Name</th></tr>
		<c:forEach items="${data.dataList}" var="name" varStatus="vstatus">
			<tr><td>${vstatus.index+1}</td><td>${name}</td></tr>
		</c:forEach>
	</table>
</body>
</html>