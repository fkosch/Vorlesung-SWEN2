<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="ISO-8859-1">
      <title>Login-Seite</title>
   </head>
   <body>
      <form action="welcome.jsp" method="post">  
         Name:<input type="text" name="name"><br>  
         Passwort:<input type="password" name="password"><br>  
         Email:<input type="email" name="email"><br>  
         <input type="submit" value="anmelden">  
      </form>  
   </body>
</html>