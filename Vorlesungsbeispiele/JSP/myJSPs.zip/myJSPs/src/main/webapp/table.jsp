<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" import="java.util.*" %>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
	<title>Tabellen-Beispiel</title>
</head>
<body>
	<jsp:useBean id="data" class="de.htwg.mybean.Data"></jsp:useBean>
	<h2>Hier wird getProperties aufgerufen:</h2>
	<jsp:getProperty property="dataList" name="data"/>
	<h2>Hier wird eine dynamische Tabelle generiert:</h2>
	<%
		List<String> names = data.getDataList();
		Iterator<String> itr = names.iterator();
	%>
	<table class="table table-striped">
		<tr>
			<th>Namen</th>
		</tr>
		<% while(itr.hasNext()) { %>
			<tr><td>
				<%= itr.next() %>
			</td></tr>
		<%}%>
	</table>
</body>
</html>