package de.htwg.mybean;

import java.io.Serializable;

public class MyBean implements Serializable {

	private static final long serialVersionUID = -8692802087106984162L;

	private String name;
	private String password;
	private String email;
	
	public MyBean() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
