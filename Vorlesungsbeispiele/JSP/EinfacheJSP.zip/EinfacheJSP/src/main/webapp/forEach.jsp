<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
	<meta charset="ISO-8859-1">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
	<title>Einfache JSP</title>
</head>
<body>
	<jsp:useBean id="MyBean" class="jsp.MyBean"></jsp:useBean>
	<table class="table table-striped">
	<tr><th>Nummer</th><th>Name</th></tr>
	<c:forEach items="${MyBean.dataList}" var="name" varStatus="vstatus">
		<tr><td>${vstatus.index+1}</td><td>${name}</td></tr>
	</c:forEach>
	</table>
</body>
</html>