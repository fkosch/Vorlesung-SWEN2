package jsp;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MyBean implements Serializable{

	private static final long serialVersionUID= -862380378676997665L;
	
	private List<String> dataList= new ArrayList<>();
	
	public MyBean() {
		dataList.add("Hund");
		dataList.add("Katze");
		dataList.add("Maus");
		dataList.add("Wolf");
		dataList.add("Elefant");
		dataList.add("Tiger");
		dataList.add("L�we");
		dataList.add("Giraffe");
		dataList.add("Panther");
		dataList.add("Affe");
			
	}

	public List<String> getDataList() {
		return dataList;
	}

	public void setDataList(List<String> dataList) {
		this.dataList = dataList;
	}
	
}
