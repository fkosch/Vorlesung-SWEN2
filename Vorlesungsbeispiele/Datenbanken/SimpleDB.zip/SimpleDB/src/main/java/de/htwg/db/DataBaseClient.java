package de.htwg.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class DataBaseClient {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/retroweb_app?useSSL=false&zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC", "user", "user");
		String url = "jdbc:postgresql://localhost/retroweb_app?user=user&password=user&ssl=false";
		Connection connection = DriverManager.getConnection(url);
		//createTableAndData(connection);
		selectStatement(connection);
		
		//createTables(connection);
		//transactionExample(connection);
		
		//preparedStatementExample(connection);
		//createRetroweb(connection);
		connection.close();
		System.out.println("Fertig!");
		
	}
	
	public static void createTableAndData(Connection connection) throws SQLException {
		Statement statement = connection.createStatement();
		
		// Vorhandene Tabelle l�schen
		statement.execute("DROP TABLE IF EXISTS Auto");
		// Tabelle anlegen
		statement.execute("CREATE TABLE Auto (Seriennr INTEGER, Typ VARCHAR(32), Kaufdatum DATE, Kosten NUMERIC);");
		// Prim�rschl�ssel einf�gen
		statement.execute("ALTER TABLE Auto ADD PRIMARY KEY (Seriennr);");
		// Werte hinzuf�gen
		statement.execute("INSERT INTO Auto (Seriennr, Typ, Kaufdatum, Kosten) VALUES (121239658, 'Audi', '2017-10-09', 31332.20);");
		statement.execute("INSERT INTO Auto (Seriennr, Typ, Kaufdatum, Kosten) VALUES (135679934, 'VW', '2015-11-12', 15232.99);");
		statement.execute("INSERT INTO Auto (Seriennr, Typ, Kaufdatum, Kosten) VALUES (148887675, 'VW', '2013-1-1', 5232.99);");
		statement.close();
	}
	
	public static void selectStatement(Connection connection) throws SQLException {
		Statement statement = connection.createStatement();
		
		ResultSet rs = statement.executeQuery("SELECT * FROM Auto");
		//("SELECT p.* FROM projects p Inner Join projects_users pu on p.id = pu.projects_id WHERE pu.users_id = 3");
		System.out.println("SELECT mit Statement");
		printResults(rs);
	}
	
	public static void preparedStatementExample(Connection connection) throws SQLException {
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM AUTO WHERE Typ = ?");
		preparedStatement.setString(1, "Audi");
		
		ResultSet rs = preparedStatement.executeQuery();
		System.out.println("SELECT mit Prepared Statement");
		printResults(rs);
		preparedStatement.close();
	}
	
	private static void createTables(Connection connection) throws SQLException {
		
		Statement statement = connection.createStatement();
		statement.execute("DROP TABLE IF EXISTS Mitarbeiter");
		statement.execute("DROP TABLE IF EXISTS Abteilung");
		statement.execute("CREATE TABLE Abteilung (ID SERIAL PRIMARY KEY, Abteilungsname VARCHAR(100));");
		statement.execute("CREATE TABLE Mitarbeiter (ID SERIAL PRIMARY KEY, Mitarbeitername VARCHAR(100), Abteilungs_ID BIGINT);");
		statement.execute("ALTER TABLE Mitarbeiter ADD FOREIGN KEY  (Abteilungs_ID) REFERENCES Abteilung(ID)");
		statement.close();
	}
	
	public static void transactionExample(Connection connection) throws SQLException {
		connection.setAutoCommit(false);
		connection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		Statement statement = connection.createStatement();
		try {
			statement.execute("INSERT INTO Abteilung (Abteilungsname) VALUES ('Abteilung 1')");
			statement.execute("INSERT INTO Mitarbeiter (Mitarbeitername, Abteilungs_ID) VALUES ('Hugo Meier', (SELECT ID FROM Abteilung WHERE Abteilungsname = 'Abteilung 1'))");
			//int i = 1/0;
			connection.commit();
		} catch(Exception e) {
			connection.rollback();
			throw e;
		} finally {
			connection.setAutoCommit(true);
			statement.close();
		}
	}
	
	public static void printResults(ResultSet rs) throws SQLException {
		ResultSetMetaData metaData = rs.getMetaData();
		int numberColumns = metaData.getColumnCount();
		String separator = "============";
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < numberColumns; i++) {
			System.out.print(metaData.getColumnName(i+1) + "\t");
			sb.append(separator);
		}
		System.out.println("\n" + sb.toString());
		while (rs.next()) {
			for (int i = 0; i < numberColumns; i++) {
				System.out.print(rs.getString(i+1) + "\t");
			}
			System.out.println("\n");
		}
	}
	
	private static void createRetroweb(Connection connection) throws SQLException {
		connection.setAutoCommit(false);
		connection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		Statement statement = connection.createStatement();
		try {
			String sql = "CREATE TABLE projects ("
				+ "	id SERIAL PRIMARY KEY,"
				+ "	name VARCHAR(255) NOT NULL UNIQUE,"
				+ "	isActive BOOLEAN NOT NULL,"
				+ "	created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,"
				+ "	updated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP"
				+ ");";
			statement.execute(sql);
			sql = "INSERT INTO projects (name, isactive, created, updated) VALUES"
				+ "	('project1', false, '2018-07-17 15:38:58', '2018-07-17 15:38:58'),"
				+ "	('project2', true, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('project3', true, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('project4', true, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('project5', true, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('project6', true, '2018-08-10 15:38:58', '2018-08-10 15:38:58');";
			statement.execute(sql);
			sql = "CREATE TABLE retros ("
				+ "	id SERIAL PRIMARY KEY,"
				+ "	name VARCHAR(255) NOT NULL,"
				+ "	scheduled TIMESTAMP NOT NULL,"
				+ "	isactive BOOLEAN NOT NULL,"
				+ "	project_id BIGINT NOT NULL,"
				+ "	foreign key (project_id) references projects(id),"
				+ "	created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,"
				+ "	updated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP"
				+ ");";
			statement.execute(sql);
			sql = "INSERT INTO retros (name, scheduled, isactive, project_id, created, updated) VALUES"
				+ "	('retro1', '2018-08-11 14:30:00', false, 1, '2018-07-17 15:38:58', '2018-07-17 15:38:58'),"
				+ "	('retro2', '2018-08-17 15:30:00', false, 2, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('retro3', '2018-09-05 15:00:00', true, 2, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('retro4', '2018-09-17 15:00:00', false, 3, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('retro5', '2018-09-18 15:00:00', false, 4, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('retro6', '2018-09-19 15:00:00', false, 5, '2018-08-10 15:38:58', '2018-08-10 15:38:58');";
			statement.execute(sql);
			sql = "CREATE TABLE users ("
				+ "	id SERIAL PRIMARY KEY,"
				+ "	username VARCHAR(255) NOT NULL UNIQUE,"
				+ "	userpw VARCHAR(255) NOT NULL,"
				+ "	email VARCHAR(255) NOT NULL,"
				+ "	isadmin BOOLEAN NOT NULL,"
				+ "	created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,"
				+ "	updated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP"
				+ ");";
			statement.execute(sql);
			sql = "INSERT INTO users (username, userpw, email, isadmin, created, updated) VALUES"
				+ "	('fritz', '$2a$12$djCFq.nuALsoNE5ZlqwBauHMmblaAmoiYSXVbQYGbfQBuL30MGI0a', 'fritz@test.de', true, '2018-07-17 15:38:58', '2018-07-17 15:38:58'),"
				+ "	('anton', '$2a$12$djCFq.nuALsoNE5ZlqwBauHMmblaAmoiYSXVbQYGbfQBuL30MGI0a', 'anton@test.de', false, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('thomas', '$2a$12$djCFq.nuALsoNE5ZlqwBauHMmblaAmoiYSXVbQYGbfQBuL30MGI0a', 'thomas@test.de', false, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('andreas', '$2a$12$djCFq.nuALsoNE5ZlqwBauHMmblaAmoiYSXVbQYGbfQBuL30MGI0a', 'andreas@test.de', false, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('susanne', '$2a$12$djCFq.nuALsoNE5ZlqwBauHMmblaAmoiYSXVbQYGbfQBuL30MGI0a', 'susanne@test.de', false, '2018-08-10 15:38:58', '2018-08-10 15:38:58'),"
				+ "	('nadine', '$2a$12$djCFq.nuALsoNE5ZlqwBauHMmblaAmoiYSXVbQYGbfQBuL30MGI0a', 'nadine@test.de', false, '2018-08-10 15:38:58', '2018-08-10 15:38:58');";
			statement.execute(sql);
			sql = "CREATE TABLE itemtypes ("
				+ "	id SERIAL PRIMARY KEY,"
				+ "	itemtype VARCHAR(255) NOT NULL,"
				+ "	created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,"
				+ "	updated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP"
				+ ");";
			statement.execute(sql);
			sql = "INSERT INTO itemtypes (itemtype, created, updated) VALUES"
				+ "	('continue', '2018-10-02 09:38:58', '2018-10-02 09:38:58'),"
				+ "	('start', '2018-10-02 09:38:58', '2018-10-02 09:38:58'),"
				+ "	('stop', '2018-10-02 09:38:58', '2018-10-02 09:38:58');";
			statement.execute(sql);
			sql = "CREATE TABLE retroitems ("
				+ "	id SERIAL PRIMARY KEY,"
				+ "	content VARCHAR(255) NOT NULL,"
				+ "	itemtype_ID BIGINT NOT NULL,"
				+ "	retro_id BIGINT,"
				+ "	user_id BIGINT,"
				+ "	foreign key (retro_id) references retros(id),"
				+ "	foreign key (user_id) references users(id),"
				+ "	foreign key (itemtype_id) references itemtypes(id),"
				+ "	created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,"
				+ "	updated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP"
				+ ");";
			statement.execute(sql);
			sql = "CREATE TABLE actionitems ("
				+ "	id SERIAL PRIMARY KEY,"
				+ "	name VARCHAR(255) NOT NULL,"
				+ "	content VARCHAR(255) NOT NULL,"
				+ "	dueDate TIMESTAMP NOT NULL,"
				+ "	isclosed BOOLEAN NOT NULL,"
				+ "	retro_id BIGINT,"
				+ "	foreign key (retro_id) references retros(id),"
				+ "	user_id BIGINT,"
				+ "	foreign key (user_id) references users(id),"
				+ "	created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,"
				+ "	updated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP"
				+ ");";
			statement.execute(sql);
			sql = "CREATE TABLE projects_users ("
				+ "	project_id BIGINT NOT NULL,"
				+ "	user_id BIGINT NOT NULL,"
				+ "	PRIMARY KEY (project_id,user_id),"
				+ "	foreign key (project_id) references projects(id),"
				+ "	foreign key (user_id) references users(id),"
				+ "	isprojectadmin BOOLEAN"
				+ ");";
			statement.execute(sql);
			sql = "INSERT INTO projects_users (project_id, user_id) VALUES"
				+ "  (1,1),"
				+ "  (2,1),"
				+ "  (3,1),"
				+ "  (4,1),"
				+ "  (5,1),"
				+ "  (6,1),"
				+ "  (1,2),"
				+ "  (2,2),"
				+ "  (2,4),"
				+ "  (3,3);";
			statement.execute(sql);
			connection.commit();
		} catch(SQLException e) {
			connection.rollback();
			throw e;
		} finally {
			connection.setAutoCommit(true);
			statement.close();
		}
	}
}
