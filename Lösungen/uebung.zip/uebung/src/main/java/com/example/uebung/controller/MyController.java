package com.example.uebung.controller;

import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MyController {
	
	    @RequestMapping(value = "/home", method = RequestMethod.GET)
	    public String home(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) {

	    	model.put("hallo", "Hallo SWEN2");
	        return "home";
	    }

}
